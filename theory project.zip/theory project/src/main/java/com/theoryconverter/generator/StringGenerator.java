package com.theoryconverter.generator;

import com.theoryconverter.model.DFA;
import java.util.*;

public class StringGenerator {
    public static List<String> generate(DFA dfa, int maxLength) {
        List<String> out = new ArrayList<>();
        List<Character> alphabet = new ArrayList<>(dfa.alphabet);
        build("", maxLength, dfa, alphabet, out);
        return out;
    }

    private static void build(String s, int max, DFA d, List<Character> alphabet, List<String> out) {
        if (d.accepts(s)) out.add(s.isEmpty() ? "ε" : s);
        if (s.length() == max) return;
        for (char symbol : alphabet) {
            build(s + symbol, max, d, alphabet, out);
        }
    }
}
