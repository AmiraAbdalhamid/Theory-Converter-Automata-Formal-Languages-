package com.theoryconverter.gui;

import com.theoryconverter.converter.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.stream.Collectors;

public class MainFrame extends JFrame {
    private static final Color BG = new Color(250, 245, 255);
    private static final Color CARD = Color.WHITE;
    private static final Color TEXT = new Color(31, 27, 46);
    private static final Color MUTED = new Color(107, 91, 149);
    private static final Color PRIMARY = new Color(126, 34, 206);
    private static final Color PRIMARY_DARK = new Color(88, 28, 135);
    private static final Color PRIMARY_LIGHT = new Color(243, 232, 255);
    private static final Color BORDER = new Color(216, 180, 254);

    private final JComboBox<String> inputType = new JComboBox<>(new String[]{
            "Regular Expression", "DFA", "NFA", "CFG regular grammar", "English Phrase"
    });
    private final JTextArea inputArea = new JTextArea(7, 44);
    private final JTextField alphabetField = new JTextField();
    private final JSpinner lengthSpinner = new JSpinner(new SpinnerNumberModel(4, 0, 10, 1));
    private final AutomatonPanel dfaPanel = new AutomatonPanel();
    private final AutomatonPanel nfaPanel = new AutomatonPanel();
    private final JTextArea dfaOut = area();
    private final JTextArea regexOut = area();
    private final JTextArea nfaOut = area();
    private final JTextArea cfgOut = area();
    private final JTextArea stringsOut = area();
    private final JTextArea englishOut = area();
    private final JTextArea simOut = area();
    private final JTextField testString = new JTextField();
    private ConversionResult current;

    public MainFrame() {
        setTitle("Theory Converter");
        setSize(1150, 790);
        setMinimumSize(new Dimension(980, 660));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        getContentPane().setBackground(BG);
        add(header(), BorderLayout.NORTH);
        add(content(), BorderLayout.CENTER);
        inputType.addActionListener(e -> updateInputTemplateForSelectedType());

        getRootPane().setDefaultButton(null);
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("control ENTER"), "convertNow");
        getRootPane().getActionMap().put("convertNow", new AbstractAction() {
            @Override public void actionPerformed(ActionEvent e) { convert(); }
        });
    }

    private JPanel header() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(PRIMARY_DARK);
        p.setBorder(new EmptyBorder(20, 28, 20, 28));
        JLabel title = new JLabel("Theory of Computation Converter");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Arial", Font.BOLD, 28));
        JLabel sub = new JLabel("Type your expression/rules, then press the purple Convert button. Use + as OR/union.");
        sub.setForeground(new Color(233, 213, 255));
        sub.setFont(new Font("Arial", Font.PLAIN, 15));
        JPanel texts = new JPanel(new GridLayout(2, 1, 0, 5));
        texts.setOpaque(false);
        texts.add(title);
        texts.add(sub);
        p.add(texts, BorderLayout.WEST);
        return p;
    }

    private JPanel content() {
        JPanel root = new JPanel(new BorderLayout(16, 16));
        root.setBackground(BG);
        root.setBorder(new EmptyBorder(18, 18, 18, 18));
        root.add(inputCard(), BorderLayout.NORTH);
        root.add(resultsTabs(), BorderLayout.CENTER);
        return root;
    }

    private JPanel inputCard() {
        JPanel card = new JPanel(new BorderLayout(12, 12));
        card.setBackground(CARD);
        card.setBorder(cardBorder());

        JPanel controls = new JPanel(new GridBagLayout());
        controls.setOpaque(false);
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(5, 6, 5, 6);
        c.gridy = 0;
        c.anchor = GridBagConstraints.WEST;
        c.fill = GridBagConstraints.NONE;

        c.gridx = 0; controls.add(label("Input Type"), c);
        c.gridx = 1; inputType.setPreferredSize(new Dimension(230, 34)); controls.add(inputType, c);
        c.gridx = 2;
        controls.add(label("1) Language Alphabet"), c);

        c.gridx = 3;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 1.0;

        alphabetField.setColumns(25);
        alphabetField.setPreferredSize(new Dimension(420, 38));
        alphabetField.setMinimumSize(new Dimension(300, 38));

        controls.add(alphabetField, c);

        c.weightx = 0;
        c.fill = GridBagConstraints.NONE;
        c.gridx = 4; controls.add(label("Max Length"), c);
        c.gridx = 5; lengthSpinner.setPreferredSize(new Dimension(75, 34)); controls.add(lengthSpinner, c);
        c.gridx = 6; c.weightx = 1; c.fill = GridBagConstraints.HORIZONTAL; controls.add(Box.createHorizontalGlue(), c);

        JButton convert = purpleButton("CONVERT");
        convert.setPreferredSize(new Dimension(150, 42));
        convert.addActionListener(e -> convert());
        JButton example = lightButton("Load Example");
        example.setPreferredSize(new Dimension(135, 42));
        example.addActionListener(e -> putExample());
        JButton clear = lightButton("Clear");
        clear.setPreferredSize(new Dimension(100, 42));
        clear.addActionListener(e -> clearAll());

        c.weightx = 0; c.fill = GridBagConstraints.NONE;
        c.gridx = 7; controls.add(convert, c);
        c.gridx = 8; controls.add(example, c);
        c.gridx = 9; controls.add(clear, c);

        JLabel guide = new JLabel("For English Phrase: write your own Language Alphabet first, then write the phrase in the input box.");
        guide.setForeground(MUTED);
        guide.setFont(new Font("Arial", Font.PLAIN, 13));
        guide.setBorder(new EmptyBorder(2, 4, 2, 4));

        inputArea.setText("");
        inputArea.setLineWrap(true);
        inputArea.setWrapStyleWord(true);
        inputArea.setFont(new Font("Monospaced", Font.PLAIN, 16));
        inputArea.setForeground(TEXT);
        inputArea.setCaretColor(PRIMARY);
        inputArea.setBorder(new EmptyBorder(10, 10, 10, 10));

        JLabel hint = new JLabel("Language Alphabet is not fixed. Write your symbols first, for example: x,y,z or h,e,l,o.");
        hint.setForeground(new Color(148, 112, 180));
        hint.setBorder(new EmptyBorder(0, 4, 0, 0));

        JPanel topWrap = new JPanel(new BorderLayout(0, 8));
        topWrap.setOpaque(false);
        topWrap.add(controls, BorderLayout.NORTH);
        topWrap.add(guide, BorderLayout.CENTER);
        topWrap.add(hint, BorderLayout.SOUTH);

        card.add(topWrap, BorderLayout.NORTH);
        card.add(new JScrollPane(inputArea), BorderLayout.CENTER);
        return card;
    }

    private JTabbedPane resultsTabs() {
        JTabbedPane tabs = new JTabbedPane();
        tabs.setFont(new Font("Arial", Font.BOLD, 13));
        dfaPanel.setEmptyMessage("DFA graph will appear here after Convert.");
        nfaPanel.setEmptyMessage("NFA graph will appear here after Convert.");
        tabs.add("DFA Graph", dfaPanel);
        tabs.add("NFA Graph", nfaPanel);
        tabs.add("Regex", scroll(regexOut));
        tabs.add("NFA", scroll(nfaOut));
        tabs.add("CFG", scroll(cfgOut));
        tabs.add("Generated Strings", scroll(stringsOut));
        tabs.add("Language Description", scroll(englishOut));
        tabs.add("Test String", simulationPanel());
        return tabs;
    }

    private JPanel simulationPanel() {
        JPanel p = new JPanel(new BorderLayout(10, 10));
        p.setBackground(CARD);
        p.setBorder(new EmptyBorder(12, 12, 12, 12));
        JPanel top = new JPanel(new BorderLayout(8, 8));
        top.setOpaque(false);
        top.add(label("Test String"), BorderLayout.WEST);
        testString.setFont(new Font("Monospaced", Font.PLAIN, 15));
        top.add(testString, BorderLayout.CENTER);
        JButton sim = purpleButton("Run Test");
        sim.addActionListener(e -> simulate());
        top.add(sim, BorderLayout.EAST);
        p.add(top, BorderLayout.NORTH);
        p.add(scroll(simOut), BorderLayout.CENTER);
        return p;
    }

    private void updateInputTemplateForSelectedType() {
        String type = (String) inputType.getSelectedItem();
        String currentText = inputArea.getText().trim();
        if (("DFA".equals(type) || "NFA".equals(type)) && currentText.isEmpty()) {
            inputArea.setText(automataTemplate());
            return;
        }
        if ("English Phrase".equals(type) && currentText.isEmpty()) {
            inputArea.setText("");
            alphabetField.setText("");
            SwingUtilities.invokeLater(() -> alphabetField.requestFocusInWindow());
        }
    }

    private String automataTemplate() {
        return "States: [q0, q1, q2]\n" +
                "Alphabet: [b]\n" +
                "Start State: q0\n" +
                "Accept States: [q2]\n\n" +
                "Transitions:\n" +
                "δ(q0, b) = [q1]\n" +
                "δ(q1, b) = [q2]";
    }

    private void putExample() {
        String type = (String) inputType.getSelectedItem();
        if (type.startsWith("Regular")) {
            inputArea.setText("(a+b+c)*ab");
            testString.setText("ccab");
        } else if (type.equals("DFA")) {
            inputArea.setText(automataTemplate());
            testString.setText("bb");
        } else if (type.equals("NFA")) {
            inputArea.setText(automataTemplate());
            testString.setText("bb");
        } else if (type.startsWith("CFG")) {
            inputArea.setText("S -> aA + bS\nA -> aA + bB\nB -> aA + bS + ε\nLanguage: ends with ab");
            testString.setText("baab");
        } else {
            alphabetField.setText("");
            inputArea.setText("");
            testString.setText("");
        }
    }

    private void convert() {
        String text = inputArea.getText().trim();

        if (text.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Please type an expression or click Load Example first.",
                    "No input",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {

            String selectedType = (String) inputType.getSelectedItem();

            // =========================
            // INVALID TYPE VALIDATION
            // =========================

            if ("English Phrase".equals(selectedType)) {

                if (text.contains("*") ||
                        text.contains("+") ||
                        text.contains("(") ||
                        text.contains(")") ||
                        text.contains("->") ||
                        text.contains("δ") ||
                        text.contains("=")) {

                    JOptionPane.showMessageDialog(this,
                            "Invalid input type.\nYou selected English Phrase but entered Regex / CFG / Automata input.",
                            "Invalid Type",
                            JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }

            if (selectedType.startsWith("Regular")) {

                String lower = text.toLowerCase();

                if (lower.contains("contain") ||
                        lower.contains("starts with") ||
                        lower.contains("ends with") ||
                        lower.contains("all strings") ||
                        lower.contains("any string")) {

                    JOptionPane.showMessageDialog(this,
                            "Invalid input type.\nYou selected Regular Expression but entered English Phrase input.",
                            "Invalid Type",
                            JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }

            if ("DFA".equals(selectedType) || "NFA".equals(selectedType)) {

                if (!text.contains("States:") ||
                        !text.contains("Transitions:")) {

                    JOptionPane.showMessageDialog(this,
                            "Invalid input type.\nAutomata input must contain States and Transitions.",
                            "Invalid Type",
                            JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }

            if (selectedType.startsWith("CFG")) {

                if (!text.contains("->")) {

                    JOptionPane.showMessageDialog(this,
                            "Invalid input type.\nCFG input must contain production rules using ->",
                            "Invalid Type",
                            JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }

            // =========================
            // NORMAL CONVERSION
            // =========================

            if ("English Phrase".equals(selectedType)
                    && alphabetField.getText().trim().isEmpty()) {

                JOptionPane.showMessageDialog(this,
                        "Please write your Language Alphabet first",
                        "Alphabet required",
                        JOptionPane.WARNING_MESSAGE);
                return;
            }

            if ("English Phrase".equals(selectedType)) {

                current = ConverterEngine.convertEnglishPhrase(
                        cleanEnglishPhraseInput(text),
                        alphabetField.getText().trim(),
                        (Integer) lengthSpinner.getValue()
                );

            } else {

                current = ConverterEngine.convert(
                        selectedType,
                        text,
                        (Integer) lengthSpinner.getValue()
                );
            }

            dfaPanel.setDfa(current.dfa);
            nfaPanel.setNfa(current.nfaModel);

            dfaOut.setText(current.dfa.asText());
            regexOut.setText(current.regex);
            nfaOut.setText(current.nfa);
            cfgOut.setText(current.cfg);

            stringsOut.setText(
                    current.strings.stream()
                            .collect(Collectors.joining("\n"))
            );

            englishOut.setText(
                    current.english != null && !current.english.isBlank()
                            ? current.english
                            : generateLanguageDescription(current.regex)
            );

            simOut.setText(
                    "Enter a test string using your selected language alphabet, then click Run Test."
            );

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(this,
                    "Cannot convert this input.\n" + ex.getMessage(),
                    "Conversion error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private String cleanEnglishPhraseInput(String text) {
        String t = text == null ? "" : text.trim();
        for (String line : t.split("\\R")) {
            String l = line.trim();
            if (l.toLowerCase().startsWith("english phrase:")) {
                return l.substring(l.indexOf(':') + 1).trim();
            }
        }
        return t;
    }

    private void simulate() {
        if (current == null) {
            JOptionPane.showMessageDialog(this, "Convert first, then run the test string.", "Convert first", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        simOut.setText(String.join("\n", current.dfa.trace(testString.getText().trim().toLowerCase())));
    }

    private void clearAll() {
        inputArea.setText("");
        testString.setText("");
        alphabetField.setText("");
        dfaOut.setText(""); regexOut.setText(""); nfaOut.setText(""); cfgOut.setText("");
        stringsOut.setText(""); englishOut.setText(""); simOut.setText("");
        dfaPanel.clearDiagram();
        nfaPanel.clearDiagram();
        current = null;
    }

    private static JLabel label(String text) {
        JLabel l = new JLabel(text + ":");
        l.setForeground(TEXT);
        l.setFont(new Font("Arial", Font.BOLD, 13));
        return l;
    }

    private static JTextArea area() {
        JTextArea a = new JTextArea();
        a.setEditable(false);
        a.setFont(new Font("Monospaced", Font.PLAIN, 14));
        a.setForeground(TEXT);
        a.setMargin(new Insets(12, 12, 12, 12));
        a.setLineWrap(false);
        return a;
    }

    private static JScrollPane scroll(JTextArea a) {
        JScrollPane s = new JScrollPane(a);
        s.setBorder(new LineBorder(new Color(233, 213, 255)));
        return s;
    }

    private static JButton purpleButton(String s) { return new RoundedButton(s, PRIMARY, Color.WHITE); }
    private static JButton lightButton(String s) { return new RoundedButton(s, PRIMARY_LIGHT, PRIMARY_DARK); }

    private static Border cardBorder() {
        return new CompoundBorder(new LineBorder(BORDER, 1, true), new EmptyBorder(14, 14, 14, 14));
    }

    private String generateLanguageDescription(String regex) {
        String r = regex == null ? "" : regex.trim().replace(" ", "");
        if (r.isEmpty() || r.equals("Custom DFA input")) {
            return "Language Description:\nAccepts the strings described by the entered automaton.";
        }

        if (r.matches("[a-z]\\+[a-z]")) {
            String[] parts = r.split("\\+");
            return "Language Description:\nAccepts strings containing either " + parts[0] + " or " + parts[1] + ".";
        }

        if (r.matches("[a-z]\\*")) {
            return "Language Description:\nAccepts zero or more occurrences of " + r.charAt(0) + ".";
        }

        if (r.matches("[a-z]{2,}")) {
            StringBuilder phrase = new StringBuilder();
            for (int i = 0; i < r.length(); i++) {
                if (i > 0 && i == r.length() - 1) phrase.append(" followed by ");
                else if (i > 0) phrase.append(", then ");
                phrase.append(r.charAt(i));
            }
            return "Language Description:\nAccepts strings containing " + phrase + ".";
        }

        if (r.contains("+") && !r.contains("*") && !r.contains("(") && !r.contains(")")) {
            String[] parts = r.split("\\+");
            if (parts.length > 1) {
                return "Language Description:\nAccepts strings containing one of these alternatives: " + String.join(", ", parts) + ".";
            }
        }

        if (r.contains("*")) {
            return "Language Description:\nAccepts strings that match the pattern " + r + ", where * means repeated zero or more times.";
        }

        return "Language Description:\nAccepts strings that match the regular expression " + r + ".";
    }

    private static class RoundedButton extends JButton {
        private final Color bg;
        private final Color fg;
        RoundedButton(String text, Color bg, Color fg) {
            super(text);
            this.bg = bg;
            this.fg = fg;
            setForeground(fg);
            setFont(new Font("Arial", Font.BOLD, 13));
            setFocusPainted(false);
            setBorderPainted(false);
            setContentAreaFilled(false);
            setOpaque(false);
            setCursor(new Cursor(Cursor.HAND_CURSOR));
            setBorder(new EmptyBorder(10, 16, 10, 16));
        }
        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            Color paint = getModel().isPressed() ? bg.darker() : (getModel().isRollover() ? bg.brighter() : bg);
            g2.setColor(paint);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 18, 18);
            g2.dispose();
            super.paintComponent(g);
        }
    }
}
