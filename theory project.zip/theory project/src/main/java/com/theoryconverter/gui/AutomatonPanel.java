package com.theoryconverter.gui;

import com.theoryconverter.model.DFA;
import com.theoryconverter.model.NFA;
import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;
import java.util.*;
import java.util.List;

public class AutomatonPanel extends JPanel {
    private List<String> states = new ArrayList<>();
    private Set<String> acceptStates = new LinkedHashSet<>();
    private String startState;
    private final Map<String, Map<String, Set<String>>> edges = new LinkedHashMap<>();
    private final Map<String, Point> positions = new LinkedHashMap<>();
    private String emptyMessage = "Automaton diagram will appear here after Convert.";

    public AutomatonPanel() {
        setPreferredSize(new Dimension(650, 360));
        setBackground(Color.WHITE);
    }

    public void setEmptyMessage(String msg) { this.emptyMessage = msg; }

    public void clearDiagram() {
        states = new ArrayList<>(); acceptStates = new LinkedHashSet<>(); startState = null; edges.clear(); positions.clear(); repaint();
    }

    public void setDfa(DFA dfa) {
        if (dfa == null) { clearDiagram(); return; }
        states = new ArrayList<>(dfa.states);
        acceptStates = new LinkedHashSet<>(dfa.acceptStates);
        startState = dfa.startState;
        edges.clear();
        for (String from : dfa.states) {
            for (Map.Entry<Character, String> e : dfa.transitions.getOrDefault(from, Map.of()).entrySet()) {
                edges.computeIfAbsent(from, k -> new LinkedHashMap<>())
                        .computeIfAbsent(e.getValue(), k -> new LinkedHashSet<>()).add(String.valueOf(e.getKey()));
            }
        }
        layoutStates(); repaint();
    }

    public void setNfa(NFA nfa) {
        if (nfa == null) { clearDiagram(); return; }
        states = new ArrayList<>(nfa.states);
        acceptStates = new LinkedHashSet<>(nfa.acceptStates);
        startState = nfa.startState;
        edges.clear();
        for (String from : nfa.states) {
            for (Map.Entry<String, Set<String>> e : nfa.transitions.getOrDefault(from, Map.of()).entrySet()) {
                for (String to : e.getValue()) {
                    edges.computeIfAbsent(from, k -> new LinkedHashMap<>())
                            .computeIfAbsent(to, k -> new LinkedHashSet<>()).add(e.getKey());
                }
            }
        }
        layoutStates(); repaint();
    }

    private void layoutStates() {
        positions.clear();
        if (states.isEmpty()) return;
        int n = states.size();
        int w = Math.max(getWidth(), 650), h = Math.max(getHeight(), 360);
        int cx = w / 2, cy = h / 2;
        int r = Math.max(70, Math.min(w, h) / 2 - 70);
        if (n <= 3) {
            int gap = Math.min(190, Math.max(120, w / (n + 1)));
            int startX = cx - gap * (n - 1) / 2;
            for (int i = 0; i < n; i++) positions.put(states.get(i), new Point(startX + i * gap, cy));
        } else {
            for (int i = 0; i < n; i++) {
                double a = 2 * Math.PI * i / n - Math.PI / 2;
                positions.put(states.get(i), new Point((int) (cx + r * Math.cos(a)), (int) (cy + r * Math.sin(a))));
            }
        }
    }

    @Override protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        if (states.isEmpty()) {
            g2.setColor(new Color(100,116,139));
            g2.setFont(new Font("Arial", Font.BOLD, 16));
            g2.drawString(emptyMessage, 150, Math.max(170, getHeight()/2));
            return;
        }
        g2.setStroke(new BasicStroke(2));
        Set<String> drawnPairs = new HashSet<>();
        for (String from : edges.keySet()) {
            for (String to : edges.get(from).keySet()) {
                String labels = String.join(",", edges.get(from).get(to));
                boolean reverseExists = edges.containsKey(to) && edges.get(to).containsKey(from) && !from.equals(to);
                String pair = from + "->" + to;
                boolean oppositeDrawn = drawnPairs.contains(to + "->" + from);
                drawTransition(g2, from, to, labels, reverseExists && oppositeDrawn);
                drawnPairs.add(pair);
            }
        }
        drawStartArrow(g2);
        for (String s : states) drawState(g2, s);
    }

    private void drawTransition(Graphics2D g2, String from, String to, String label, boolean flipCurve) {
        Point a = positions.get(from), b = positions.get(to);
        if (a == null || b == null) return;
        g2.setColor(new Color(100,116,139));
        g2.setStroke(new BasicStroke(2));
        if (from.equals(to)) {
            g2.draw(new Arc2D.Double(a.x - 24, a.y - 70, 58, 48, 25, 300, Arc2D.OPEN));
            drawArrow(g2, a.x + 15, a.y - 60, a.x + 27, a.y - 42);
            g2.setColor(new Color(124,58,237));
            g2.drawString(label, a.x + 18, a.y - 62);
            return;
        }
        double dx = b.x - a.x, dy = b.y - a.y, len = Math.hypot(dx, dy);
        if (len == 0) return;
        int radius = 30;
        double sx = a.x + dx / len * radius, sy = a.y + dy / len * radius;
        double ex = b.x - dx / len * radius, ey = b.y - dy / len * radius;
        double bend = flipCurve ? -7.0 : 7.0;
        double ctrlX = (sx + ex) / 2 - dy / bend;
        double ctrlY = (sy + ey) / 2 + dx / bend;
        QuadCurve2D q = new QuadCurve2D.Double(sx, sy, ctrlX, ctrlY, ex, ey);
        g2.draw(q);
        drawArrow(g2, ctrlX, ctrlY, ex, ey);
        g2.setColor(new Color(124,58,237));
        g2.setFont(new Font("Arial", Font.BOLD, 12));
        g2.drawString(label, (int) ctrlX, (int) ctrlY - 4);
    }

    private void drawArrow(Graphics2D g2, double sx, double sy, double ex, double ey) {
        double ang = Math.atan2(ey - sy, ex - sx);
        int size = 9;
        Path2D p = new Path2D.Double();
        p.moveTo(ex, ey);
        p.lineTo(ex - size * Math.cos(ang - .45), ey - size * Math.sin(ang - .45));
        p.lineTo(ex - size * Math.cos(ang + .45), ey - size * Math.sin(ang + .45));
        p.closePath();
        g2.fill(p);
    }

    private void drawStartArrow(Graphics2D g2) {
        Point p = positions.get(startState);
        if (p == null) return;
        g2.setColor(new Color(124,58,237));
        g2.setStroke(new BasicStroke(2));
        g2.drawLine(p.x - 92, p.y, p.x - 36, p.y);
        drawArrow(g2, p.x - 92, p.y, p.x - 36, p.y);
        g2.setFont(new Font("Arial", Font.BOLD, 12));
        g2.drawString("start", p.x - 94, p.y - 9);
    }

    private void drawState(Graphics2D g2, String s) {
        Point p = positions.get(s);
        if (p == null) return;
        boolean acc = acceptStates.contains(s);
        g2.setColor(new Color(237,233,254));
        g2.fillOval(p.x - 30, p.y - 30, 60, 60);
        g2.setColor(new Color(124,58,237));
        g2.setStroke(new BasicStroke(3));
        g2.drawOval(p.x - 30, p.y - 30, 60, 60);
        // Final states are marked with + only, without a double circle.
        g2.setColor(new Color(15,23,42));
        g2.setFont(new Font("Arial", Font.BOLD, 13));
        FontMetrics fm = g2.getFontMetrics();
        String label = (s.equals(startState) ? "- " : "") + s;
        g2.drawString(label, p.x - fm.stringWidth(label) / 2, acc ? p.y : p.y + 5);
        if (acc) {
            g2.setFont(new Font("Arial", Font.BOLD, 18));
            FontMetrics plusFm = g2.getFontMetrics();
            g2.drawString("+", p.x - plusFm.stringWidth("+") / 2, p.y + 20);
        }
    }
}
