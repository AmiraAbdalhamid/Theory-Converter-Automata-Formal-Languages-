package com.theoryconverter.converter;

import com.theoryconverter.model.DFA;
import com.theoryconverter.model.NFA;
import java.util.*;

public class ConversionResult {
    public DFA dfa;
    public NFA nfaModel;
    public String regex;
    public String nfa;
    public String cfg;
    public List<String> strings = new ArrayList<>();
    public String english;
    public String notes;
}
