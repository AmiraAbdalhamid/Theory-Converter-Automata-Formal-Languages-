package com.theoryconverter.converter;

import com.theoryconverter.model.DFA;
import com.theoryconverter.model.NFA;
import com.theoryconverter.generator.StringGenerator;
import java.util.*;

public class ConverterEngine {
    private static int nextId;

    private record Fragment(String start, String end) {}

    public static ConversionResult convert(String inputType, String input, int maxLength) {
        String normalized = input == null ? "" : input.trim();
        ConversionResult r = new ConversionResult();

        if (inputType != null && inputType.equals("DFA")) {
            r.dfa = parseDfa(normalized);
            r.nfaModel = dfaAsNfa(r.dfa);
            r.regex = "Custom DFA input";
            r.nfa = "Every DFA is also an NFA.\n\n" + r.nfaModel.asText();
            r.cfg = "Regular grammar can be generated from the DFA table.";
            r.english = englishFromInput(normalized, r.dfa);
            r.strings = StringGenerator.generate(r.dfa, maxLength);
            r.notes = "DFA mode reads the States / Alphabet / Start State / Accept States / Transitions template.";
            return r;
        }

        if (inputType != null && inputType.equals("NFA")) {
            r.nfaModel = parseNfa(normalized);
            r.dfa = minimizeDfa(nfaToDfa(r.nfaModel));
            r.regex = "Custom NFA input";
            r.nfa = r.nfaModel.asText();
            r.cfg = "Regular grammar can be generated from the converted DFA table.";
            r.english = "Custom NFA with alphabet " + r.nfaModel.alphabet + ".";
            r.strings = StringGenerator.generate(r.dfa, maxLength);
            r.notes = "NFA mode reads the States / Alphabet / Start State / Accept States / Transitions template.";
            return r;
        }

        String regex = extractRegex(normalized);
        validateRegex(regex);
        r.nfaModel = regexToNfa(regex);
        r.dfa = minimizeDfa(nfaToDfa(r.nfaModel));
        r.regex = regex;
        r.nfa = r.nfaModel.asText();
        r.cfg = grammarHint(regex, r.dfa);
        r.english = languageDescription(regex);
        r.strings = StringGenerator.generate(r.dfa, maxLength);
        r.notes = "Regex → clean NFA, then NFA → DFA with Subset Construction. Missing transitions are treated as rejected instead of drawing a confusing dead state.";
        return r;
    }



    public static ConversionResult convertEnglishPhrase(String phrase, String alphabetText, int maxLength) {
        String alphabetRegex = alphabetToRegex(alphabetText);
        String regex = regexFromEnglishPhrase(phrase, alphabetRegex);
        ConversionResult r = convert("Regular Expression", regex, maxLength);
        r.english = "English phrase: " + phrase.trim() + "\nLanguage alphabet: " + alphabetText.trim() + "\nConverted regex: " + regex;
        return r;
    }

    private static String alphabetToRegex(String alphabetText) {
        String clean = alphabetText == null ? "" : alphabetText.toLowerCase().replaceAll("[\\s,{}]+", "");
        LinkedHashSet<Character> symbols = new LinkedHashSet<>();
        for (char c : clean.toCharArray()) {
            if (c >= 'a' && c <= 'z') symbols.add(c);
            else throw new IllegalArgumentException("Alphabet must contain letters a-z only. Write your own symbols separated by commas or spaces.");
        }
        if (symbols.isEmpty()) throw new IllegalArgumentException("Please write your Language Alphabet first");
        return symbols.stream().map(String::valueOf).collect(java.util.stream.Collectors.joining("+", "(", ")"));
    }

    private static String regexFromEnglishPhrase(String phrase, String alphabetRegex) {
        String p = phrase == null ? "" : phrase.trim().toLowerCase();
        if (p.isEmpty()) throw new IllegalArgumentException("Please write an English phrase after choosing the alphabet");

        java.util.regex.Matcher m;

        // The English words are only an instruction/description, not symbols in the language.
        // Example: alphabet = a,b,e,r and phrase = "that contain all strings" means all strings over {a,b,e,r}.
        if (p.matches(".*\b(all strings|any string|any strings|all words|any word|everything)\b.*")) {
            return alphabetRegex + "*";
        }

        m = java.util.regex.Pattern.compile("(?:starts? with|begin(?:s)? with)\s+([a-z]+)").matcher(p);
        if (m.find()) return requireInAlphabet(m.group(1), alphabetRegex) + alphabetRegex + "*";

        m = java.util.regex.Pattern.compile("(?:ends? with)\s+([a-z]+)").matcher(p);
        if (m.find()) return alphabetRegex + "*" + requireInAlphabet(m.group(1), alphabetRegex);

        m = java.util.regex.Pattern.compile("(?:contains?|containing)\s+([a-z]+)").matcher(p);
        if (m.find()) return alphabetRegex + "*" + requireInAlphabet(m.group(1), alphabetRegex) + alphabetRegex + "*";

        m = java.util.regex.Pattern.compile("(?:only|zero or more|any number of)\s+([a-z])").matcher(p);
        if (m.find()) return requireInAlphabet(m.group(1), alphabetRegex) + "*";

        // If the phrase is just a general sentence, do not validate its letters against the alphabet.
        // Treat it as a request to generate all strings from the alphabet.
        return alphabetRegex + "*";
    }

    private static String requireInAlphabet(String word, String alphabetRegex) {
        for (char c : word.toCharArray()) {
            if (alphabetRegex.indexOf(c) < 0) {
                throw new IllegalArgumentException("The phrase uses symbol '" + c + "' but it is not in the Language Alphabet.");
            }
        }
        return word;
    }

    private static String extractRegex(String input) {
        String s = input.replace(" ", "").toLowerCase();
        for (String line : input.split("\\R")) {
            String l = line.trim();
            if (l.toLowerCase().startsWith("regex:")) return l.substring(l.indexOf(':') + 1).replace(" ", "").toLowerCase();
        }
        return s;
    }

    private static void validateRegex(String s) {
        if (s.isEmpty()) throw new IllegalArgumentException("Please type a regular expression, like x+z or (a+b)*ab.");
        int bal = 0;
        char prev = 0;
        for (char c : s.toCharArray()) {
            if (!(c >= 'a' && c <= 'z') && c != '+' && c != '*' && c != '(' && c != ')') {
                throw new IllegalArgumentException("Allowed symbols are letters a-z, +, *, (, ). Wrong symbol: " + c);
            }
            if (c == '(') bal++;
            if (c == ')') bal--;
            if (bal < 0) throw new IllegalArgumentException("Parentheses are not balanced.");
            if (c == '+' && (prev == 0 || prev == '+' || prev == '(')) throw new IllegalArgumentException("+ must be between two expressions, like a+b.");
            prev = c;
        }
        if (bal != 0) throw new IllegalArgumentException("Parentheses are not balanced.");
        if (s.endsWith("+") || s.endsWith("(")) throw new IllegalArgumentException("Expression is incomplete.");
    }

    private static NFA regexToNfa(String regex) {
        // Build a clean epsilon-free NFA using the position/followpos method.
        // This gives simple graphs for examples like f+h instead of a large Thompson graph.
        String postfix = toPostfix(addConcat(regex));
        class Node {
            boolean nullable;
            Set<Integer> first = new LinkedHashSet<>();
            Set<Integer> last = new LinkedHashSet<>();
        }
        Map<Integer, Character> symbolAt = new LinkedHashMap<>();
        Map<Integer, Set<Integer>> follow = new LinkedHashMap<>();
        ArrayDeque<Node> stack = new ArrayDeque<>();
        int posCounter = 1;

        for (char token : postfix.toCharArray()) {
            if (token >= 'a' && token <= 'z') {
                Node n = new Node();
                n.nullable = false;
                n.first.add(posCounter);
                n.last.add(posCounter);
                symbolAt.put(posCounter, token);
                follow.put(posCounter, new LinkedHashSet<>());
                posCounter++;
                stack.push(n);
            } else if (token == '.') {
                Node right = stack.pop(), left = stack.pop();
                for (int i : left.last) follow.get(i).addAll(right.first);
                Node n = new Node();
                n.nullable = left.nullable && right.nullable;
                n.first.addAll(left.first);
                if (left.nullable) n.first.addAll(right.first);
                n.last.addAll(right.last);
                if (right.nullable) n.last.addAll(left.last);
                stack.push(n);
            } else if (token == '+') {
                Node right = stack.pop(), left = stack.pop();
                Node n = new Node();
                n.nullable = left.nullable || right.nullable;
                n.first.addAll(left.first); n.first.addAll(right.first);
                n.last.addAll(left.last); n.last.addAll(right.last);
                stack.push(n);
            } else if (token == '*') {
                Node child = stack.pop();
                for (int i : child.last) follow.get(i).addAll(child.first);
                Node n = new Node();
                n.nullable = true;
                n.first.addAll(child.first);
                n.last.addAll(child.last);
                stack.push(n);
            }
        }
        if (stack.size() != 1) throw new IllegalArgumentException("Invalid regular expression.");
        Node root = stack.pop();

        NFA nfa = new NFA();
        nfa.setStartState("q0");
        if (root.nullable) nfa.acceptStates.add("q0");
        for (int pos : symbolAt.keySet()) nfa.addState("q" + pos, root.last.contains(pos));

        for (int pos : root.first) {
            nfa.addTransition("q0", String.valueOf(symbolAt.get(pos)), "q" + pos);
        }
        for (Map.Entry<Integer, Set<Integer>> e : follow.entrySet()) {
            String from = "q" + e.getKey();
            for (int toPos : e.getValue()) {
                nfa.addTransition(from, String.valueOf(symbolAt.get(toPos)), "q" + toPos);
            }
        }
        return nfa;
    }

    private static String newState() { return "n" + nextId++; }

    private static boolean atom(char c) { return (c >= 'a' && c <= 'z') || c == ')' || c == '*'; }
    private static boolean atomStart(char c) { return (c >= 'a' && c <= 'z') || c == '('; }

    private static String addConcat(String s) {
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            out.append(c);
            if (i + 1 < s.length() && atom(c) && atomStart(s.charAt(i + 1))) out.append('.');
        }
        return out.toString();
    }

    private static int prec(char op) {
        return switch (op) { case '*' -> 3; case '.' -> 2; case '+' -> 1; default -> 0; };
    }

    private static String toPostfix(String s) {
        StringBuilder out = new StringBuilder();
        ArrayDeque<Character> ops = new ArrayDeque<>();
        for (char c : s.toCharArray()) {
            if (c >= 'a' && c <= 'z') out.append(c);
            else if (c == '(') ops.push(c);
            else if (c == ')') {
                while (!ops.isEmpty() && ops.peek() != '(') out.append(ops.pop());
                if (ops.isEmpty()) throw new IllegalArgumentException("Parentheses are not balanced.");
                ops.pop();
            } else {
                while (!ops.isEmpty() && ops.peek() != '(' && prec(ops.peek()) >= prec(c)) out.append(ops.pop());
                ops.push(c);
            }
        }
        while (!ops.isEmpty()) {
            if (ops.peek() == '(') throw new IllegalArgumentException("Parentheses are not balanced.");
            out.append(ops.pop());
        }
        return out.toString();
    }

    private static DFA nfaToDfa(NFA nfa) {
        DFA dfa = new DFA();
        Map<Set<String>, String> names = new LinkedHashMap<>();
        ArrayDeque<Set<String>> queue = new ArrayDeque<>();

        Set<String> start = nfa.epsilonClosure(Set.of(nfa.startState));
        names.put(start, "q0");
        queue.add(start);
        dfa.setStartState("q0");
        dfa.addState("q0", intersects(start, nfa.acceptStates));

        int counter = 1;
        Set<String> deadSet = Set.of();
        while (!queue.isEmpty()) {
            Set<String> current = queue.remove();
            String fromName = names.get(current);
            for (char c : nfa.alphabet) {
                Set<String> move = nfa.move(current, c);
                if (move.isEmpty()) continue; // no dead-state drawing; missing transition means reject
                Set<String> next = nfa.epsilonClosure(move);
                if (!names.containsKey(next)) {
                    String name = "q" + counter++;
                    names.put(next, name);
                    dfa.addState(name, intersects(next, nfa.acceptStates));
                    queue.add(next);
                }
                dfa.addTransition(fromName, c, names.get(next));
            }
        }
        return dfa;
    }


    private static DFA minimizeDfa(DFA dfa) {
        if (dfa == null || dfa.states.isEmpty()) return dfa;
        List<Character> alphabet = new ArrayList<>(dfa.alphabet);
        Map<String, Integer> cls = new LinkedHashMap<>();
        for (String s : dfa.states) cls.put(s, dfa.acceptStates.contains(s) ? 1 : 0);

        boolean changed;
        do {
            changed = false;
            Map<String, Integer> sigToClass = new LinkedHashMap<>();
            Map<String, Integer> nextCls = new LinkedHashMap<>();
            int nextId = 0;
            for (String state : dfa.states) {
                StringBuilder sig = new StringBuilder();
                sig.append(dfa.acceptStates.contains(state) ? "A" : "N");
                for (char c : alphabet) {
                    String to = dfa.transitions.getOrDefault(state, Map.of()).get(c);
                    sig.append('|').append(c).append(':').append(to == null ? "-" : cls.get(to));
                }
                String key = sig.toString();
                if (!sigToClass.containsKey(key)) sigToClass.put(key, nextId++);
                nextCls.put(state, sigToClass.get(key));
            }
            if (!nextCls.equals(cls)) changed = true;
            cls = nextCls;
        } while (changed);

        Map<Integer, String> className = new LinkedHashMap<>();
        int counter = 0;
        int startClass = cls.get(dfa.startState);
        className.put(startClass, "q0");
        for (String state : dfa.states) {
            int id = cls.get(state);
            if (!className.containsKey(id)) className.put(id, "q" + (++counter));
        }

        DFA out = new DFA();
        out.setStartState("q0");
        for (String state : dfa.states) {
            String name = className.get(cls.get(state));
            out.addState(name, dfa.acceptStates.contains(state));
        }
        for (String state : dfa.states) {
            String from = className.get(cls.get(state));
            for (Map.Entry<Character, String> e : dfa.transitions.getOrDefault(state, Map.of()).entrySet()) {
                String to = className.get(cls.get(e.getValue()));
                out.addTransition(from, e.getKey(), to);
            }
        }
        return out;
    }

    private static boolean intersects(Set<String> a, Set<String> b) {
        for (String x : a) if (b.contains(x)) return true;
        return false;
    }

    private static NFA dfaAsNfa(DFA d) {
        NFA n = new NFA();
        n.setStartState(d.startState);
        for (String s : d.states) n.addState(s, d.acceptStates.contains(s));
        for (String from : d.states) {
            for (Map.Entry<Character, String> e : d.transitions.getOrDefault(from, Map.of()).entrySet()) n.addTransition(from, String.valueOf(e.getKey()), e.getValue());
        }
        return n;
    }

    private static DFA parseDfa(String input) {
        ParsedAutomaton p = parseAutomatonText(input);
        if (p.transitions.isEmpty()) throw new IllegalArgumentException("DFA input needs transition lines like δ(q0, b) = [q1]");
        DFA d = new DFA();
        d.setStartState(p.startState);
        for (String state : p.states) d.addState(state, p.acceptStates.contains(state));
        for (char symbol : p.alphabet) d.alphabet.add(symbol);
        for (ParsedTransition t : p.transitions) {
            if (t.toStates.isEmpty()) continue;
            if (t.toStates.size() > 1) throw new IllegalArgumentException("DFA transition must have one target only. For multiple targets, choose NFA.");
            d.addTransition(t.from, t.symbol, t.toStates.get(0));
        }
        for (String a : p.acceptStates) d.acceptStates.add(a);
        return d;
    }

    private static NFA parseNfa(String input) {
        ParsedAutomaton p = parseAutomatonText(input);
        if (p.transitions.isEmpty()) throw new IllegalArgumentException("NFA input needs transition lines like δ(q0, b) = [q1]");
        NFA n = new NFA();
        n.setStartState(p.startState);
        for (String state : p.states) n.addState(state, p.acceptStates.contains(state));
        for (ParsedTransition t : p.transitions) {
            if (t.toStates.isEmpty()) continue;
            for (String to : t.toStates) n.addTransition(t.from, String.valueOf(t.symbol), to);
        }
        for (String a : p.acceptStates) n.acceptStates.add(a);
        return n;
    }

    private record ParsedTransition(String from, char symbol, List<String> toStates) {}
    private record ParsedAutomaton(Set<String> states, Set<Character> alphabet, String startState, Set<String> acceptStates, List<ParsedTransition> transitions) {}

    private static ParsedAutomaton parseAutomatonText(String input) {
        LinkedHashSet<String> states = new LinkedHashSet<>();
        LinkedHashSet<Character> alphabet = new LinkedHashSet<>();
        LinkedHashSet<String> accept = new LinkedHashSet<>();
        ArrayList<ParsedTransition> transitions = new ArrayList<>();
        String start = null;

        for (String raw : input.split("\\R")) {
            String line = raw.trim();
            if (line.isEmpty() || line.toLowerCase().startsWith("transitions:")) continue;
            String lower = line.toLowerCase();
            if (lower.startsWith("states:")) {
                states.addAll(parseStateList(line.substring(line.indexOf(':') + 1)));
            } else if (lower.startsWith("alphabet:")) {
                for (String x : parseStateList(line.substring(line.indexOf(':') + 1))) {
                    if (x.length() != 1 || !Character.isLetter(x.charAt(0))) throw new IllegalArgumentException("Alphabet must contain single letters like [a, b]");
                    alphabet.add(Character.toLowerCase(x.charAt(0)));
                }
            } else if (lower.startsWith("start state:") || lower.startsWith("start:")) {
                start = cleanToken(line.substring(line.indexOf(':') + 1));
                if (!start.isEmpty()) states.add(start);
            } else if (lower.startsWith("accept states:") || lower.startsWith("accept:") || lower.startsWith("final:")) {
                accept.addAll(parseStateList(line.substring(line.indexOf(':') + 1)));
                states.addAll(accept);
            } else {
                ParsedTransition t = parseTransitionLine(line);
                if (t != null) {
                    transitions.add(t);
                    states.add(t.from);
                    states.addAll(t.toStates);
                    alphabet.add(t.symbol);
                }
            }
        }

        if (start == null || start.isBlank()) {
            if (!states.isEmpty()) start = states.iterator().next();
            else if (!transitions.isEmpty()) start = transitions.get(0).from;
        }
        if (start == null || start.isBlank()) throw new IllegalArgumentException("Please write Start State, for example: Start State: q0");
        if (states.isEmpty()) states.add(start);
        return new ParsedAutomaton(states, alphabet, start, accept, transitions);
    }

    private static ParsedTransition parseTransitionLine(String line) {
        java.util.regex.Matcher greek = java.util.regex.Pattern
                .compile("δ\\s*\\(\\s*([^,]+)\\s*,\\s*([a-zA-Z])\\s*\\)\\s*=\\s*\\[?([^\\]]+)\\]?")
                .matcher(line);
        if (greek.find()) {
            return new ParsedTransition(cleanToken(greek.group(1)), Character.toLowerCase(greek.group(2).charAt(0)), parseStateList(greek.group(3)).stream().toList());
        }
        if (line.contains("->") && line.contains(",")) {
            String[] sides = line.split("->", 2);
            String[] left = sides[0].split(",", 2);
            if (left.length == 2) {
                String from = cleanToken(left[0]);
                String sym = cleanToken(left[1]).toLowerCase();
                if (!sym.isEmpty()) return new ParsedTransition(from, sym.charAt(0), parseStateList(sides[1]).stream().toList());
            }
        }
        return null;
    }

    private static List<String> parseStateList(String text) {
        String cleaned = text.replace("[", "").replace("]", "").replace("{", "").replace("}", "").trim();
        ArrayList<String> out = new ArrayList<>();
        for (String part : cleaned.split(",")) {
            String token = cleanToken(part);
            if (!token.isEmpty() && !token.equals("-")) out.add(token);
        }
        return out;
    }

    private static String cleanToken(String s) {
        return s == null ? "" : s.trim().replace("[", "").replace("]", "").replace("{", "").replace("}", "");
    }

    private static String englishFromInput(String input, DFA dfa) {
        for (String raw : input.split("\\R")) {
            String line = raw.trim();
            if (line.toLowerCase().startsWith("language:")) return line.substring(line.indexOf(':') + 1).trim();
        }
        return "Custom DFA with alphabet " + dfa.alphabet + ".";
    }


    private static String languageDescription(String regex) {
        String clean = regex == null ? "" : regex.replace(" ", "").toLowerCase();

        if (clean.matches("[a-z]\\+[a-z]")) {
            return "Language Description:\nAccepts strings containing either " + clean.charAt(0) + " or " + clean.charAt(2) + ".";
        }

        if (clean.matches("[a-z]\\*")) {
            return "Language Description:\nAccepts zero or more occurrences of " + clean.charAt(0) + ".";
        }

        if (clean.matches("[a-z]+")) {
            return "Language Description:\nAccepts strings containing " + clean + ".";
        }

        if (clean.matches("\\([a-z](\\+[a-z])+\\)[a-z]+")) {
            int close = clean.indexOf(')');
            String choices = clean.substring(1, close).replace("+", " or ");
            String suffix = clean.substring(close + 1);
            return "Language Description:\nAccepts strings that start with either " + choices + " followed by " + suffix + ".";
        }

        if (clean.contains("+")) {
            String[] parts = clean.split("\\+");
            if (parts.length == 2) {
                return "Language Description:\nAccepts strings containing either " + parts[0] + " or " + parts[1] + ".";
            }
        }

        if (clean.endsWith("*") && clean.length() > 1) {
            return "Language Description:\nAccepts zero or more repetitions of " + clean.substring(0, clean.length() - 1) + ".";
        }

        return "Language Description:\nAccepts the language represented by the regular expression: " + clean + ".";
    }

    private static String grammarHint(String regex, DFA dfa) {
        StringBuilder sb = new StringBuilder();
        sb.append("Right-linear grammar from the DFA:\n");
        for (String s : dfa.states) {
            for (Map.Entry<Character, String> e : dfa.transitions.getOrDefault(s, Map.of()).entrySet()) {
                sb.append(s).append(" -> ").append(e.getKey()).append(e.getValue()).append("\n");
            }
            if (dfa.acceptStates.contains(s)) sb.append(s).append(" -> ε\n");
        }
        return sb.toString();
    }
}
