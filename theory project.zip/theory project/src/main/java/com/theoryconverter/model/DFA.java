package com.theoryconverter.model;

import java.util.*;

public class DFA {
    public final List<String> states = new ArrayList<>();
    public final Set<Character> alphabet = new LinkedHashSet<>();
    public final Map<String, Map<Character, String>> transitions = new LinkedHashMap<>();
    public String startState;
    public final Set<String> acceptStates = new LinkedHashSet<>();

    public void addState(String s, boolean accept) {
        if (!states.contains(s)) states.add(s);
        transitions.putIfAbsent(s, new LinkedHashMap<>());
        if (accept) acceptStates.add(s);
    }

    public void setStartState(String s) { startState = s; addState(s, false); }

    public void addTransition(String from, char symbol, String to) {
        addState(from, false); addState(to, false);
        alphabet.add(symbol);
        transitions.get(from).put(symbol, to);
    }

    public boolean accepts(String input) {
        String current = startState;
        for (char c : input.toCharArray()) {
            Map<Character, String> row = transitions.get(current);
            if (row == null || !row.containsKey(c)) return false;
            current = row.get(c);
        }
        return acceptStates.contains(current);
    }

    public List<String> trace(String input) {
        List<String> steps = new ArrayList<>();
        String current = startState;
        steps.add("Start at " + current);
        for (char c : input.toCharArray()) {
            Map<Character, String> row = transitions.get(current);
            if (row == null || !row.containsKey(c)) {
                steps.add("No transition from " + current + " on " + c + " → Rejected");
                return steps;
            }
            String next = row.get(c);
            steps.add(current + " --" + c + "--> " + next);
            current = next;
        }
        steps.add("End at " + current + (acceptStates.contains(current) ? " → Accepted" : " → Rejected"));
        return steps;
    }

    public String asText() {
        StringBuilder sb = new StringBuilder();
        sb.append("States: ").append(states).append("\n");
        sb.append("Alphabet: ").append(alphabet).append("\n");
        sb.append("Start State: ").append(startState).append("\n");
        sb.append("Accept States: ").append(acceptStates).append("\n\nTransitions:\n");
        for (String s : states) {
            Map<Character, String> row = transitions.getOrDefault(s, Map.of());
            for (char c : alphabet) sb.append("δ(").append(s).append(", ").append(c).append(") = ").append(row.getOrDefault(c, "-")).append("\n");
        }
        return sb.toString();
    }
}
