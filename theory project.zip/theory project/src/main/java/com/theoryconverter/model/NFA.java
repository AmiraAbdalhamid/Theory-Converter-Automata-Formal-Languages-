package com.theoryconverter.model;

import java.util.*;

public class NFA {
    public static final String EPSILON = "ε";

    public final List<String> states = new ArrayList<>();
    public final Set<Character> alphabet = new LinkedHashSet<>();
    public final Map<String, Map<String, Set<String>>> transitions = new LinkedHashMap<>();
    public String startState;
    public final Set<String> acceptStates = new LinkedHashSet<>();

    public void addState(String s, boolean accept) {
        if (!states.contains(s)) states.add(s);
        transitions.putIfAbsent(s, new LinkedHashMap<>());
        if (accept) acceptStates.add(s);
    }

    public void setStartState(String s) {
        startState = s;
        addState(s, false);
    }

    public void addTransition(String from, String symbol, String to) {
        addState(from, false);
        addState(to, false);
        if (!EPSILON.equals(symbol) && symbol.length() == 1) alphabet.add(symbol.charAt(0));
        transitions.computeIfAbsent(from, k -> new LinkedHashMap<>())
                .computeIfAbsent(symbol, k -> new LinkedHashSet<>()).add(to);
    }

    public Set<String> epsilonClosure(Set<String> input) {
        LinkedHashSet<String> result = new LinkedHashSet<>(input);
        ArrayDeque<String> stack = new ArrayDeque<>(input);
        while (!stack.isEmpty()) {
            String s = stack.pop();
            for (String to : transitions.getOrDefault(s, Map.of()).getOrDefault(EPSILON, Set.of())) {
                if (result.add(to)) stack.push(to);
            }
        }
        return result;
    }

    public Set<String> move(Set<String> input, char c) {
        LinkedHashSet<String> out = new LinkedHashSet<>();
        for (String s : input) out.addAll(transitions.getOrDefault(s, Map.of()).getOrDefault(String.valueOf(c), Set.of()));
        return out;
    }

    public String asText() {
        StringBuilder sb = new StringBuilder();
        sb.append("States: ").append(states).append("\n");
        sb.append("Alphabet: ").append(alphabet).append("\n");
        sb.append("Start State: ").append(startState).append("\n");
        sb.append("Accept States: ").append(acceptStates).append("\n\nTransitions:\n");
        for (String from : states) {
            Map<String, Set<String>> row = transitions.getOrDefault(from, Map.of());
            for (String sym : row.keySet()) {
                sb.append("δ(").append(from).append(", ").append(sym).append(") = ").append(row.get(sym)).append("\n");
            }
        }
        return sb.toString();
    }
}
