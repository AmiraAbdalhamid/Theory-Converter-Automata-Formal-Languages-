# Easy Theory Converter Project

Open in IntelliJ, set Project SDK if asked, then run:
src/main/java/com/theoryconverter/Main.java

How to use:
1. Choose Input Type.
2. Click Example to insert a ready input.
3. Click Convert.
4. Open the output tabs: DFA, Regex, CFG, Strings, English, Simulation.
5. Enter a test string and press Simulate.
